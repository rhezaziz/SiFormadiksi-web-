<?php
defined('BASEPATH') or exit('No direct script access allowed');

$route['default_controller'] = 'user';

// Bagian link buat web admin
$route['admin'] = 'auth';
$route['admin/dashboard'] = 'admin/dashboard';
$route['admin/anggota'] = 'admin/anggota';
$route['admin/pendaftar'] = 'admin/pendaftar';
$route['admin/survey'] = 'admin/survey';


$route['admin/profil'] = 'admin/profil';

$route['admin/edit_akun'] = 'admin/edit_akun';
$route['admin/kelola_akun-changePassword'] = 'admin/kelola_akun/changePassword';
$route['admin/setting'] = 'admin/setting';











$route['api/example/users/(:num)'] = 'api/example/users/id/$1'; // Example 4
$route['api/example/users/(:num)(\.)([a-zA-Z0-9_-]+)(.*)'] = 'api/example/users/id/$1/format/$3$4'; // Example 8

$route['404_override'] = '';
$route['translate_uri_dashes'] = false;
