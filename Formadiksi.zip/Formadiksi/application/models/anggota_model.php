<?php
defined('BASEPATH') or exit('No direct script access allowed');

class anggota_model extends CI_Model
{
    private $_table = "Anggota";

    public $id_anggota;
    public $Nama_anggota;
    public $NIM;
    public $Jurusan;
    public $Alamat_anggota;
    
    
    public function rules()
    {
        return [
            [
                'field' => 'Nama_anggota',
                'label' => 'Nama Anggota',
                'rules' => 'required',
            ]
        ];
        //     ,
        //     [
        //         'field' => 'kategori',
        //         'label' => 'Kategori',
        //         'rules' => 'required',
        //     ]
        // ];
    }

    public function getAnggota()
    {
         return $this->db->get($this->_table)->result();
    }

    public function getById($id)
    {
        return $this->db->get_where($this->_table, ["id_anggota" => $id])->row();
    }


    public function addAnggota($Nama_anggota, $NIM, $Jurusan, $Alamat_anggota, $Foto)
    {
        $this->Nama_anggota = $Nama_anggota;
        $this->NIM = $NIM;
        $this->Jurusan = $Jurusan;
        $this->Alamat_anggota = $Alamat_anggota;
    

        return $this->db->insert($this->_table, $this);
    }

    public function deleteAnggota($id)
    {
        $this->_deleteImage($id);
        return $this->db->delete($this->_table, array("id_anggota" => $id));
    }

    public function updateProduk($id_pendaftar, $nama_pendaftar, $nim_pendaftar, $jurusan, $alamat_pendaftar )
    {
        $this->id_pendaftar = $id_pendaftar;
        $this->nama_pendaftar = $nama_pendaftar;
        $this->nim_pendaftar = $nim_pendaftar;
        $this->jurusan = $jurusan;
        $this->alamat_pendaftar = $alamat_pendaftar;
        

        return $this->db->update($this->_table, $this, array('id_pendaftar' => $id));
    }

    private function _deleteImage($id)
    {

        $anggota = $this->getById($id);
        $path = 'upload/anggota/' . $anggota->foto;
        $this->load->helper("file"); // load the helper
        delete_files($path, true); // delete all files/folders

        rmdir('upload/anggota/' . $anggota->foto);
    }
}
