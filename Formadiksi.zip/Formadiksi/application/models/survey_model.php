<?php
defined('BASEPATH') or exit('No direct script access allowed');

class survey_model extends CI_Model
{
    private $_table = "Survey";

    public $id_survey;
    public $Nama;
    public $nim;
    public $jurusan;
    public $foto;
    
    public function rules()
    {
        return [
            [
                'field' => 'nama',
                'label' => 'Nama Anggota',
                'rules' => 'required',
            ]
        ];
        //     ,
        //     [
        //         'field' => 'kategori',
        //         'label' => 'Kategori',
        //         'rules' => 'required',
        //     ]
        // ];
    }

    public function getSurvey()
    {
         return $this->db->get($this->_table)->result();
    }

    public function getById($id)
    {
        return $this->db->get_where($this->_table, ["id_survey" => $id])->row();
    }


    public function addAnggota($nama, $nim, $jurusan, $foto)
    {
        $this->nama = $nama;
        $this->nim = $nim;
        $this->jurusan = $jurusan;
        // $this->Alamat_anggota = $Alamat_anggota;
        $this->foto = $foto;

        return $this->db->insert($this->_table, $this);
    }

    public function deleteSurvey($id)
    {
        $this->_deleteImage($id);
        return $this->db->delete($this->_table, array("id_survey" => $id));
    }

    public function updateProduk($id_pendaftar, $nama_pendaftar, $nim_pendaftar, $jurusan, $alamat_pendaftar, $foto )
    {
        $this->id_pendaftar = $id_pendaftar;
        $this->nama_pendaftar = $nama_pendaftar;
        $this->nim_pendaftar = $nim_pendaftar;
        $this->jurusan = $jurusan;
        $this->alamat_pendaftar = $alamat_pendaftar;
        $this->foto = $foto;

        return $this->db->update($this->_table, $this, array('id_pendaftar' => $id));
    }

    private function _deleteImage($id)
    {

        $anggota = $this->getById($id);
        $path = 'upload/anggota/' . $anggota->foto;
        $this->load->helper("file"); // load the helper
        delete_files($path, true); // delete all files/folders

        rmdir('upload/anggota/' . $anggota->foto);
    }
}
