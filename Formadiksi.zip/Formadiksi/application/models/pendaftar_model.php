<?php
defined('BASEPATH') or exit('No direct script access allowed');

class pendaftar_model extends CI_Model
{
    private $_table = "Pendaftar";

    public $id_pendaftar;
    public $nama_pendaftar;
    public $nim_pendaftar;
    public $jurusan;
    public $alamat_pendaftar;
    public $foto;
    
    public function rules()
    {
        return [
            [
                'field' => 'nama_pendaftar',
                'label' => 'Nama Pendaftar',
                'rules' => 'required',
            ]
        ];
        //     ,
        //     [
        //         'field' => 'kategori',
        //         'label' => 'Kategori',
        //         'rules' => 'required',
        //     ]
        // ];
    }

    public function getPendaftar()
    {
         return $this->db->get($this->_table)->result();
    }

    public function getById($id)
    {
        return $this->db->get_where($this->_table, ["id_pendaftar" => $id])->row();
    }


    public function addPendaftar($nama_produk, $nim_pendaftar, $jurusan, $alamat_pendaftar, $foto)
    {
        $this->nama_pendaftar = $nama_pendaftar;
        $this->nim_pendaftar = $nim_pendaftar;
        $this->jurusan = $jurusan;
        $this->alamat_pendaftar = $alamat_pendaftar;
        $this->foto = $foto;

        return $this->db->insert($this->_table, $this);
    }

    public function deletePendaftar($id)
    {
        $this->_deleteImage($id);
        return $this->db->delete($this->_table, array("id_pendaftar" => $id));
    }

    public function updateProduk($id_pendaftar, $nama_pendaftar, $nim_pendaftar, $jurusan, $alamat_pendaftar, $foto )
    {
        $this->id_pendaftar = $id_pendaftar;
        $this->nama_pendaftar = $nama_pendaftar;
        $this->nim_pendaftar = $nim_pendaftar;
        $this->jurusan = $jurusan;
        $this->alamat_pendaftar = $alamat_pendaftar;
        $this->foto = $foto;

        return $this->db->update($this->_table, $this, array('id_pendaftar' => $id));
    }

    private function _deleteImage($id)
    {

        $pendaftar = $this->getById($id);
        $path = 'upload/pendaftar/' . $pendaftar->foto;
        $this->load->helper("file"); // load the helper
        delete_files($path, true); // delete all files/folders

        rmdir('upload/pendaftar/' . $pendaftar->foto);
    }
}
