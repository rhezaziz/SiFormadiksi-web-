<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Anggota extends CI_Controller
{
    public function __construct(){
            parent::__construct();
        if (isset($this->session->userdata['logged_in'])) {
            $email = ($this->session->userdata['logged_in']['email']);
        } else {
            redirect('auth');
        }

        $this->load->model('anggota_model');
       // $this->load->model('produk_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $data['anggota'] = $this->anggota_model->getAnggota();
        $data['main_content'] = 'admin/anggota';
        $data['title_dashboard'] = 'Pendaftar';
        
        //$data['produk'] = $this->produk_model->getProduk('JK03');
        $this->load->view('admin/overview', $data);
    }

    public function tambahAnggota()
    {
        $Anggota = $this->anggota_model;
        $validation = $this->form_validation;
        $validation->set_rules($Anggota->rules());

        if ($validation->run() == false) {
            $this->session->set_flashdata('error', 'Data Pendaftar gagal ditambahkan');
            redirect('admin/anggota');
        } else {
            
            $post = $this->input->post();
            $Nama_anggota = $post['Nama_anggota'];
            $NIM = $post['NIM'];
            $Jurusan = $post['Jurusan'];
            $Alamat_anggota = $post['Alamat_anggota'];

            if ($NIM != false) {
                if ($Pendaftar->addAnggota($Nama_anggota, $NIM, $Jurusan , $Alamat_anggota)) {
                    $this->session->set_flashdata('success', 'Data berhasil ditambahkan');
                    redirect('admin/anggota');
                }
            } else {
                $this->session->set_flashdata('error', 'Gambar tidak ada');
                redirect('admin/anggota');
            }
        }
    }

    public function updateProduk($id, $gambarInfo)
    {
        $pendaftar = $this->pendaftar_model;
        $validation = $this->form_validation;
        $validation->set_rules($pendaftar->rules());
        if ($validation->run() == false) {
            $this->session->set_flashdata('error', 'Data produk gagal diperbarui');
            redirect('admin/pendaftar/infoProduk/' . $id);
        } else {
            $gambar = $this->_uploadImage();
            $post = $this->input->post();
            $nama = $post['nama_produk'];
            $deskripsi = $post['deskripsi'];
            $kategori = $post['kategori'];

            if ($gambar != false) {
                if ($produk->updateProduk($id, $nama, $deskripsi, $kategori, $gambar)) {
                    $path = 'upload/produk/' . $gambarInfo;
                    $this->load->helper("file"); // load the helper
                    delete_files($path, true); // delete all files/folders
                    rmdir('./upload/produk/' . $gambarInfo);
                    $this->session->set_flashdata('success', 'Data berhasil diperbarui');
                    redirect('admin/produk_bedug/infoProduk/' . $id);
                }
            } else {
                if ($produk->updateProduk($id, $nama, $deskripsi, $kategori, $gambarInfo)) {
                    $this->session->set_flashdata('success', 'Data berhasil diperbarui');
                    redirect('admin/produk_bedug/infoProduk/' . $id);
                }
            }
        }
    }

    public function infoProduk($id)
    {
        $data['main_content'] = 'admin/info_produk';
        $data['data_produk'] = $this->produk_model->getById($id);
        $data['id_produk'] = $id;
        $data['coba'] = $this->produk_model->getById($id)->nama_produk;
        $data['gambar_produk'] = $this->produk_model->getById($id)->gambar;
        $data['info_kategori'] = 'Produk Bedug';
        $data['title_dashboard'] = 'Info Produk';
        $this->load->view('admin/overview', $data);
    }

    public function hapusAnggota($id)
    {
        if ($this->pendaftar_model->deleteAnggota($id)) {
            $this->session->set_flashdata('success', 'Data berhasil dihapus');
            redirect('admin/anggota');
        }
    }

    private function _uploadImage()
    {
        $config['upload_path']          = './upload/anggota/';
        $config['allowed_types']        = 'gif|jpg|png|jpeg';
        $config['file_name']            = date("ymdhis");
        $config['overwrite']            = true;
        $config['max_size']             = 1024;

        $this->load->library('upload', $config);

        if($this->upload->do_upload('Foto')){
            return $this->upload->data("file_name");
        }

        return false;
    }
}
