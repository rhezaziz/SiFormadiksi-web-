<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Survey extends CI_Controller
{
    public function __construct(){
            parent::__construct();
        if (isset($this->session->userdata['logged_in'])) {
            $email = ($this->session->userdata['logged_in']['email']);
        } else {
            redirect('auth');
        }

        $this->load->model('survey_model');
       // $this->load->model('produk_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $data['survey'] = $this->survey_model->getSurvey();
        $data['main_content'] = 'admin/survey';
        $data['title_dashboard'] = 'Survey';
        //$data['produk'] = $this->produk_model->getProduk('JK03');
        $this->load->view('admin/overview', $data);
    }

    public function tambahSurvey()
    {
        $Survey = $this->survey_model;
        $validation = $this->form_validation;
        $validation->set_rules($Survey->rules());

        if ($validation->run() == false) {
            $this->session->set_flashdata('error', 'Data Pendaftar gagal ditambahkan');
            redirect('admin/survey');
        } else {
            $foto = $this->_uploadImage();
            $post = $this->input->post();
            $nama = $post['nama'];
            $nim = $post['nim'];
            $jurusan = $post['jurusan'];
            

            if ($foto != false) {
                if ($Pendaftar->addPendaftar($nama, $nim, $jurusan , $foto)) {
                    $this->session->set_flashdata('success', 'Data berhasil ditambahkan');
                    redirect('admin/survey');
                }
            } else {
                $this->session->set_flashdata('error', 'Gambar tidak ada');
                redirect('admin/survey');
            }
        }
    }

    public function updateProduk($id, $gambarInfo)
    {
        $pendaftar = $this->pendaftar_model;
        $validation = $this->form_validation;
        $validation->set_rules($pendaftar->rules());
        if ($validation->run() == false) {
            $this->session->set_flashdata('error', 'Data produk gagal diperbarui');
            redirect('admin/pendaftar/infoProduk/' . $id);
        } else {
            $gambar = $this->_uploadImage();
            $post = $this->input->post();
            $nama = $post['nama_produk'];
            $deskripsi = $post['deskripsi'];
            $kategori = $post['kategori'];

            if ($gambar != false) {
                if ($produk->updateProduk($id, $nama, $deskripsi, $kategori, $gambar)) {
                    $path = 'upload/produk/' . $gambarInfo;
                    $this->load->helper("file"); // load the helper
                    delete_files($path, true); // delete all files/folders
                    rmdir('./upload/produk/' . $gambarInfo);
                    $this->session->set_flashdata('success', 'Data berhasil diperbarui');
                    redirect('admin/produk_bedug/infoProduk/' . $id);
                }
            } else {
                if ($produk->updateProduk($id, $nama, $deskripsi, $kategori, $gambarInfo)) {
                    $this->session->set_flashdata('success', 'Data berhasil diperbarui');
                    redirect('admin/produk_bedug/infoProduk/' . $id);
                }
            }
        }
    }

    public function infoProduk($id)
    {
        $data['main_content'] = 'admin/info_produk';
        $data['data_produk'] = $this->produk_model->getById($id);
        $data['id_produk'] = $id;
        $data['coba'] = $this->produk_model->getById($id)->nama_produk;
        $data['gambar_produk'] = $this->produk_model->getById($id)->gambar;
        $data['info_kategori'] = 'Produk Bedug';
        $data['title_dashboard'] = 'Info Produk';
        $this->load->view('admin/overview', $data);
    }

    public function hapusSurvey($id)
    {
        if ($this->survey_model->deleteSurvey($id)) {
            $this->session->set_flashdata('success', 'Data berhasil dihapus');
            redirect('admin/survey');
        }
    }

    private function _uploadImage()
    {
        $config['upload_path']          = './upload/pendaftar/';
        $config['allowed_types']        = 'gif|jpg|png|jpeg';
        $config['file_name']            = date("ymdhis");
        $config['overwrite']            = true;
        $config['max_size']             = 1024;

        $this->load->library('upload', $config);

        if($this->upload->do_upload('foto')){
            return $this->upload->data("file_name");
        }

        return false;
    }
}
