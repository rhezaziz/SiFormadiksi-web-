

<div class="modal fade" id="modalFormAkun" tabindex="-1" role="form" aria-labelledby="mediumModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="mediumModalLabel">Data Akun Baru</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo base_url('admin/kelola_akun/' . $title_dashboard) ?>" method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="Email">Email</label>
                        <span id="pesan" class="error"></span></p>
                        <input type="email" class="form-control txtOnly" id="email" name="email" placeholder="Masukkan Email" oninvalid="this.setCustomValidity('Form tidak boleh kosong!')" required />
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <span id="pesan" class="error"></span></p>
                        <input type="password" class="form-control txtOnly" id="password" name="password" placeholder="Masukkan Password" oninvalid="this.setCustomValidity('Form tidak boleh kosong!')" required />
                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                <button type="submit" class="btn btn-primary">Masukan</button>
                </form>
            </div>
        </div>
    </div>
</div>




<div class="modal fade" id="modalFormPendaftar" tabindex="-1" role="dialog" aria-labelledby="mediumModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="mediumModalLabel">Data Pendaftar Baru</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo base_url('admin/' . strtolower(str_replace(' ', '_', $title_dashboard)) . '/tambahPendaftar') ?>" method="post" role="form" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="Nama Pendaftar">Nama Pendaftar</label>
                        <input type="text" class="form-control" id="nama_pendaftar" name="nama_pendaftar" placeholder="Masukkan Nama Pendaftar" pattern="[a-zA-Z0-9\s\-]+" required="required" />
                    </div>
                    <div class="form-group">
                        <label for="NIM Pendaftar">NIM Pendaftar</label>
                        <input type="text" class="form-control" id="nim_pendaftar" name="nim_pendaftar" placeholder="Masukkan NIM Pendaftar" pattern="[a-zA-Z0-9\s\-]+" required="required" />
                    </div>
                    

                    

          
                        <div class="form-group">
                            <label for="jurusan">Jurusan</label>
                            <select name="kategori" id="kategori" name="kategori" class="form-control" required="required">
                                <option value="">Pilih Jurusan</option>

                                <option value="TI">Teknik Informatika</option>
                                <option value="TM">Teknik Mesin</option>
                                <option value="TP">Teknik Pendingin Udara</option>
                               
                                        <span class="arrow">
                            <i class="fas fa-angle-down"></i>
                        </span>
                                        
                        
                                     
                                    
                            </select>
                        </div>
                   

                    <div class="form-group">
                        <label for="Alamat Pendaftar">Alamat Pendaftar</label>
                        <input type="text" class="form-control" id="alamat_pendaftar" name="alamat_pendaftar" placeholder="Masukkan Alamat Pendaftar" pattern="[a-zA-Z0-9\s\-]+" required="required" />
                    </div>

                    Pilih File :
                    <div class="form-group">
                        <label for="foto"></label>
                        <input class="form-contr" type="file" name="foto" required />
                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                <button type="submit" class="btn btn-primary">Masukan</button>
                </form>
            </div>
        </div>
    </div>
</div>




<div class="modal fade" id="modalFormAnggota" tabindex="-1" role="dialog" aria-labelledby="mediumModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="mediumModalLabel">Data Produk Baru</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo base_url('admin/' . strtolower(str_replace(' ', '_', $title_dashboard)) . '/tambahAnggota') ?>" method="post" role="form" enctype="multipart/form-data">
                    

                   
                        <div class="form-group">
                            <label for="Anggota">Anggota</label>
                            <select name="anggota" id="anggota" name="anggota" class="form-control" required="required">
                                <option value="">Pilih NIM Pendaftar</option>
                                <?php foreach ($pendaftar as $data_pendaftar) : ?>
                                    <option value="<?php echo $data_pendaftar->id_pendaftar ?>"> <?php echo $data_pendaftar->nim_pendaftar ?> </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                   
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                <button type="submit" class="btn btn-primary">Masukan</button>
                </form>
            </div>
        </div>
    </div>
</div>



