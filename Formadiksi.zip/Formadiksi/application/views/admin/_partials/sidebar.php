<aside class="menu-sidebar2">
    <div class="logo">
        <a href="#">
            <img style="margin-top:5px; width:200px; height:50px; margin-left:10px;" src="<?php echo base_url('img/bidik.png') ?>" alt="Cool Admin" />
        </a>
    </div>
    <div class="menu-sidebar2__content js-scrollbar1">
        <nav class="navbar-sidebar2">
            <ul class="list-unstyled navbar__list">
                <li>
                    <a href="<?php echo site_url('admin/dashboard') ?>">
                        </i>Dashboard
                    </a>
                </li>
                <li class="has-sub">
                    <a href="<?php echo site_url('admin/pendaftar') ?>">

                        </i>Pendaftar
                       
                    </a>
                   
                </li>

                <li class="has-sub">
                    <a href="<?php echo site_url('admin/anggota') ?>">
                        </i>Anggota
                        
                    </a>
                    
                </li>

            

                <li>
                    <a href="<?php echo site_url('admin/survey') ?>">
                        </i>Survey</a>
                </li>

                <li>
                    <a href="<?php echo site_url('admin/bahan_produk') ?>">
                        Hasil Survey</a>
                </li>

            </ul>
        </nav>
    </div>
</aside>