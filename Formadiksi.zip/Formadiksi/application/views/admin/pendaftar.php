<div class="card">
    <div class="card-header">
        <strong class="card-title">Data Pendaftar</strong>
        <button class="au-btn au-btn-icon au-btn--green" data-toggle="modal" data-target="#modalFormPendaftar">
            <i class="zmdi zmdi-plus"></i>Tambah</button>
    </div>



    <div class="card-body">
        <table id="tabel-data" class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th width="60px">NO</th>
                    <th>Nama</th>
                    <th>NIM</th>
                    <th>Jurusan</th>
                    <th>Alamat</th>
                    <th>Foto rumah</th>
                    <th width="200px">AKSI</th>
                </tr>
            </thead>
            <tbody>
                <?php $i = 1;
                 //$Pendaftar = $this->pendaftar_model;
                foreach ($pendaftar as $data_pendaftar) : ?>
                <tr class="tr-shadow">
                    <td>
                        <?php echo $i;
                        $i++; ?>
                    </td>
               <!--  </tr> -->
                <td>
                    <?php echo $data_pendaftar->nama_pendaftar ?>
                </td>
                    <td>
                       <?php echo $data_pendaftar->nim_pendaftar ?>
                    </td>
                    <td>
                        <?php echo $data_pendaftar->jurusan ?>
                    </td>

                    <td>
                        <?php echo $data_pendaftar->alamat_pendaftar ?>
                    </td>

                  <!--   <td>
                         <?php $originalDate = $data_testimoni->tanggal;
                        $newDate = date("d-m-Y", strtotime($originalDate));
                        echo $newDate; ?> 
                    </td> -->
                    <td>
                        <div>
                            <a href="<?php echo base_url('upload/pendaftar/' . $data_pendaftar->foto) ?>" class="btn btn-outline-secondary image-popup-vertical-fit">Lihat Gambar</a>
                        </div>
                    </td>

                    <td>
                        <button onclick="deleteConfirm('<?php echo site_url('admin/pendaftar/hapusPendaftar/' . $data_pendaftar->id_pendaftar . '/' . $title_dashboard) ?>')" class="btn btn-danger" type="button" title="Delete">
                            Hapus
                        </button>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table> <br>
    </div>
</div> 