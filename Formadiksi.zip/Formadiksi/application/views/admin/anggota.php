<div class="card">
    <div class="card-header">
        <strong class="card-title">Data Anggota</strong>
        <button class="au-btn au-btn-icon au-btn--green" data-toggle="modal" data-target="#modalFormAnggota">
            <i class="zmdi zmdi-plus"></i>Tambah</button>
    </div>



    <div class="card-body">
        <table id="tabel-data" class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th width="60px">NO</th>
                    <th>Nama</th>
                    <th>NIM</th>
                    <th>Jurusan</th>
                    <th>Alamat</th>
                
                    <th width="200px">AKSI</th>
                </tr>
            </thead>
            <tbody>
                <?php $i = 1;
                foreach ($anggota as $data_anggota) : ?>
                <tr class="tr-shadow">
                    <td>
                        <?php echo $i;
                        $i++; ?>
                    </td>
                    <td>
                        <?php echo $data_anggota->Nama_anggota ?>
                    </td>

                    <td>
                         <?php echo $data_anggota->NIM ?>
                    </td>

                    <td>
                        <?php echo $data_anggota->Jurusan ?>
                    </td>

                     <td>
                        <?php echo $data_anggota->Alamat_anggota ?>
                    </td>
                    

                    <td>
                        <button onclick="deleteConfirm('<?php echo site_url('admin/anggota/deleteAnggota/' . $data_anggota->id_anggota . '/' . $title_dashboard) ?>')" class="btn btn-danger" type="button" title="Delete">
                            Hapus
                        </button>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table> <br>
    </div>
</div> 