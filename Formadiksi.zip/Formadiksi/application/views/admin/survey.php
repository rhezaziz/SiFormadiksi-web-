<div class="card">
    <div class="card-header">
        <strong class="card-title">Data Survey</strong>
        <button class="au-btn au-btn-icon au-btn--green" data-toggle="modal" data-target="#modalTestimoni">
            <i class="zmdi zmdi-plus"></i>Tambah</button>
    </div>



    <div class="card-body">
        <table id="tabel-data" class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th width="60px">NO</th>
                    <th>Nama</th>
                    <th>NIM</th>
                    <th>Jurusan</th>
                    <th>Foto rumah</th>
                    <th width="200px">AKSI</th>
                </tr>
            </thead>
            <tbody>
                <?php $i = 1;
                foreach ($survey as $data_survey) : ?>
                <tr class="tr-shadow">
                    <td>
                        <?php echo $i;
                        $i++; ?>
                    </td>
                    <td>
                       <?php echo $data_survey->nama ?>
                    </td>

                    <td>
                        <?php echo $data_survey->nim ?>
                    </td>

                    <td>
                         <?php echo $data_survey->jurusan ?>
                    </td>
                    <td>
                        <div>
                            <a href="<?php echo base_url('upload/pendaftar/' . $data_survey->foto) ?>" class="btn btn-outline-secondary image-popup-vertical-fit">Lihat Gambar</a>
                        </div>
                    </td>

                    <td>
                        <button onclick="deleteConfirm('<?php echo site_url('admin/Survey/deleteSurvey/' . $data_survey->id_survey . '/' . $title_dashboard) ?>')" class="btn btn-danger" type="button" title="Delete">
                            Hapus
                        </button>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table> <br>
    </div>
</div> 