<!DOCTYPE html>
<html lang="en">

<!-- HEAD -->
<?php $this->load->view('User/_partials/head.php') ?>

<body>
    <header class="header_area">
        <!-- BAGIAN HALAMAN NAVBAR-->
        <?php $this->load->view('User/_partials/navbar.php') ?>
       
        <!-- BAGIAN HALAMAN SECTION-->
        <?php $this->load->view('User/_partials/section.php') ?>

        <!-- BAGIAN HALAMAN SECTION1-->
        <?php $this->load->view('User/_partials/section1.php') ?>

        <!-- BAGIAN HALAMAN SECTION2-->
        <?php $this->load->view('User/_partials/section2.php') ?>

        <!-- BAGIAN HALAMAN SECTION3-->
        <?php $this->load->view('User/_partials/section3.php') ?>

        <?php $this->load->view('User/_partials/section4.php') ?>

        <?php $this->load->view('User/_partials/section5.php') ?>
         
        <!-- BAGIAN HALAMAN FOOTER-->
        <?php $this->load->view('User/_partials/footer.php') ?>


         <script src="<?php echo base_url('assets/js/jquery.min.js')?>"></script>  
  <!-- Include all compiled plugins (below), or include individual files as needed -->
  <script src="<?php echo base_url('assets/js/bootstrap.js')?>"></script>   
  <!-- Slick slider -->
  <script type="text/javascript" src="<?php echo base_url('assets/js/slick.js')?>"></script>
  <!-- Counter -->
  <script type="text/javascript" src="<?php echo base_url('assets/js/waypoints.js')?>"></script>
  <script type="text/javascript" src="<?php echo base_url('assets/js/jquery.counterup.js')?>"></script>  
  <!-- Mixit slider -->
  <script type="text/javascript" src="<?php echo base_url('assets/js/jquery.mixitup.js')?>"></script>
  <!-- Add fancyBox -->        
  <script type="text/javascript" src="<?php echo base_url('assets/js/jquery.fancybox.pack.js')?>"></script>
  
  
  <!-- Custom js -->
  <script src="<?php echo base_url('assets/js/custom.js')?>"></script> 

</body>

</html>
<!-- end document--> 