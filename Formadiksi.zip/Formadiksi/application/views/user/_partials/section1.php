<!--         <section class="furniture_area p_120">
        	<div class="container">
        		<div class="main_title">
        			<h2>PRODUK UNGGULAN</h2>
        			<p>Dibawah ini adalah produk-produk unggulan dari perusahaan kami yang akhir-akhir ini banyak diminati dan dipesan oleh konsumen dari berbagai kota diluar majalengka khususnya.</p>
        		</div>

        		
        		<div class="furniture_inner row">
        			<div class="col-lg-4">
        				<div class="furniture_item">
        					<img class="img-fluid" src="<?php echo base_url('img/furniture/bedug4.jpg')?>"  alt="">
        					<h4>BEDUG CIREBON</h4>
        					<p>Sony laptops are among the most well known laptops on today’s market. Sony is a name that.</p>
        				</div>
        			</div>
        			<div class="col-lg-4">
        				<div class="furniture_item">
        					<img class="img-fluid" src="<?php echo base_url('img/furniture/bedug3.jpg')?>"  alt="">
        					<h4>BEDUG INDRAMAYU</h4>
        					<p>Sony laptops are among the most well known laptops on today’s market. Sony is a name that.</p>
        				</div>
        			</div>
        			<div class="col-lg-4">
        				<div class="furniture_item">
        					<img class="img-fluid" src="<?php echo base_url('img/furniture/bedug4.jpg')?>"  alt="">
        					<h4>BEDUG MAJALENGKA</h4>
        					<p>Sony laptops are among the most well known laptops on today’s market. Sony is a name that.</p>
        				</div>
        			</div>
        		</div>


        	</div>
        </section> -->



        <section id="mu-slider">
    <!-- Start single slider item -->
    <div class="mu-slider-single">
      <div class="mu-slider-img">
        <figure>
          <img href="<?php echo base_url('assets/img/slider/1.jpg')?>" alt="img">
        </figure>
      </div>
      <div class="mu-slider-content">
        <h4>Welcome To Varsity</h4>
        <span></span>
        <h2>We Will Help You To Learn</h2>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolor amet error eius reiciendis eum sint unde eveniet deserunt est debitis corporis temporibus recusandae accusamus.</p>
        <a href="#" class="mu-read-more-btn">Read More</a>
      </div>
    </div>
    <!-- Start single slider item -->
    <!-- Start single slider item -->
    <div class="mu-slider-single">
      <div class="mu-slider-img">
        <figure>
          <img href="<?php echo base_url('assets/img/slider/2.jpg')?>" alt="img">
        </figure>
      </div>
      <div class="mu-slider-content">
        <h4>Premiumu Quality Free Template</h4>
        <span></span>
        <h2>Best Education Template Ever</h2>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolor amet error eius reiciendis eum sint unde eveniet deserunt est debitis corporis temporibus recusandae accusamus.</p>
        <a href="#" class="mu-read-more-btn">Read More</a>
      </div>
    </div>
    <!-- Start single slider item -->
    <!-- Start single slider item -->
    <div class="mu-slider-single">
      <div class="mu-slider-img">
        <figure>
          <img href="<?php echo base_url('assets/img/slider/3.jpg')?>" alt="img">
        </figure>
      </div>
      <div class="mu-slider-content">
        <h4>Exclusivly For Education</h4>
        <span></span>
        <h2>Education For Everyone</h2>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolor amet error eius reiciendis eum sint unde eveniet deserunt est debitis corporis temporibus recusandae accusamus.</p>
        <a href="#" class="mu-read-more-btn">Read More</a>
      </div>
    </div>
    <!-- Start single slider item -->    
  </section>