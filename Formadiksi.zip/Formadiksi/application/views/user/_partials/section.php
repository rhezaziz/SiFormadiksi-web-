<!-- <section class="home_banner_area">
            <div class="banner_inner">
				<div class="container">
					<div class="row">
						<div class="col-lg-8">
							<div class="banner_content">
								<h2><br><br>Pemesanan Mebel & Kusen <br/>PT Jati Makmur Mandiri (JMM)</h2>
								<p>Merupakan sebuah perangkat lunak (software) yang digunakan untuk pemesanan produk Mebel dan kusen dengan berbasis website dan android.</p>
								<a class="banner_btn" href="<?php echo base_url('user/pesansekarang') ?>">Pesan Sekarang</a>
								<a class="banner_btn" href="<?php echo base_url('user/carapesan') ?>">Baca Cara Pesan</a>
							</div>
						</div>

                      
						<div class="col-lg-4">
							<div class="home_right_box">
								<a style="color:white; " class="home_item" href="<?php echo base_url('user/furniture') ?>">
								    <img class="img-fluid" src="<?php echo base_url('img/furniture/sofa.png')?>"  alt="Mebel">
									<br>
								</a>
								<a style="color:white;" class="home_item" href="<?php echo base_url('user/kusen') ?>">
									<img class="img-fluid" src="<?php echo base_url('img/furniture/meja.png')?>"  alt="Kusen">
									<br>
								</a>
								<a style="color:white;" class="home_item" href="<?php echo base_url('user/bedug') ?>">
									<img class="img-fluid" src="<?php echo base_url('img/furniture/bedug.png')?>"  alt="bedug">
									<br>
								</a>

								<div class="home_item">
									<i class="flaticon-computer"></i>
								</div>
								<div class="home_item">
									<i class="flaticon-mirror"></i>
								</div>
								<div class="home_item">
									<i class="flaticon-closet"></i>
								</div>
								<div class="home_item">
									<i class="flaticon-kitchen"></i>
								</div>
							</div>
						</div>
					</div>
				</div>
            </div>
        </section> -->



        <section id="mu-menu">
    <nav class="navbar navbar-default" role="navigation">  
      <div class="container">
        <div class="navbar-header">
          <!-- FOR MOBILE VIEW COLLAPSED BUTTON -->
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <!-- LOGO -->              
          <!-- TEXT BASED LOGO -->
          <a class="navbar-brand" href="index.html"><i class="fa fa-university"></i><span>Varsity</span></a>
          <!-- IMG BASED LOGO  -->
          <!-- <a class="navbar-brand" href="index.html"><img src="assets/img/logo.png" alt="logo"></a> -->
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul id="top-menu" class="nav navbar-nav navbar-right main-nav">
            <li class="active"><a href="index.html">Home</a></li>            
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">Course <span class="fa fa-angle-down"></span></a>
              <ul class="dropdown-menu" role="menu">
                <li><a href="course.html">Course Archive</a></li>                
                <li><a href="course-detail.html">Course Detail</a></li>                
              </ul>
            </li>           
            <li><a href="gallery.html">Gallery</a></li>
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">Blog <span class="fa fa-angle-down"></span></a>
              <ul class="dropdown-menu" role="menu">
                <li><a href="blog-archive.html">Blog Archive</a></li>                
                <li><a href="blog-single.html">Blog Single</a></li>                
              </ul>
            </li>            
            <li><a href="contact.html">Contact</a></li>
            <li><a href="404.html">404 Page</a></li>               
            <li><a href="#" id="mu-search-icon"><i class="fa fa-search"></i></a></li>
          </ul>                     
        </div><!--/.nav-collapse -->        
      </div>     
    </nav>
  </section>